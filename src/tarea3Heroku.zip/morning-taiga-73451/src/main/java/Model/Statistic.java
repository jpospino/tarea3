package Model;

public class Statistic {
    private int programID;
    private double estimatedProxySize;
    private double planAddedModifiedSize;
    private double actualAddedModifiedSize;
    private double actualDevelopmentTime;
    
    public Statistic(int pgrID, double ePS, double pAMS, double aAMS, double aDT) 
    {
        this.programID = pgrID;
        this.estimatedProxySize = ePS;
        this.planAddedModifiedSize = pAMS;
        this.actualAddedModifiedSize = aAMS;
        this.actualDevelopmentTime = aDT;
    }    

    public double getEstimatedProxySize() 
    {
        return this.estimatedProxySize;
    }

    public double getPlanAddedModifiedSize()
    {  
        return this.planAddedModifiedSize; 
    }

    public double getActualAddedModifiedSize()
    {  
        return this.actualAddedModifiedSize; 
    }

    public double getActualDevelopmentTime()
    {  
        return this.actualDevelopmentTime; 
    }
    
    public double estimatedProxySizeSquared()
    {  
        return this.estimatedProxySize * this.estimatedProxySize;
    }
    
    public double planAddedModifiedSizeSquared()
    {  
        return this.planAddedModifiedSize * this.planAddedModifiedSize; 
    }
    
    public double actualAddedModifiedSizeSquared()
    {  
        return this.actualAddedModifiedSize * this.actualAddedModifiedSize; 
    }
    
    public double actualDevelopmentTimeSquared()
    {  
        return this.actualDevelopmentTime * this.actualDevelopmentTime; 
    }
    
    public double estimatedProxySizeActualAddedModifiedSize()
    {  
        return this.estimatedProxySize * this.actualAddedModifiedSize; 
    }
    
    public double estimatedProxySizeActualDevelopmentTime()
    {  
        return this.estimatedProxySize * this.actualDevelopmentTime; 
    }

    public double planAddedModifiedSizeActualAddedModifiedSize()
    {  
        return this.planAddedModifiedSize * this.actualAddedModifiedSize; 
    }

    public double planAddedModifiedSizeActualDevelopmentTime()
    {  
        return this.planAddedModifiedSize * this.actualDevelopmentTime; 
    }
}
