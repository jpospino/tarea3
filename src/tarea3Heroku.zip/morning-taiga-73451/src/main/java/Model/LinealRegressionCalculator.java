package Model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class LinealRegressionCalculator {
    public List<Statistic> statistic = new ArrayList();
    
    public LinealRegressionCalculator()
    {
        //this.statistic = new ArrayList<Statistic>();
    }
    public void addStatictics(int pgrID, double ePS, double pAMS, double aAMS, double aDH) 
    { 
        this.statistic.add(new Statistic(pgrID, ePS, pAMS, aAMS, aDH));
    }
    
    
    public double sumEstimatedProxySize()
    {
        return this.statistic.stream().mapToDouble( x -> x.getEstimatedProxySize()).sum();
    } 
        
    public double sumActualAddedModifiedSize()
    {
        return this.statistic.stream().mapToDouble( x -> x.getActualAddedModifiedSize()).sum();
    } 
    public double sumEstimatedProxySizeSquared()
    { 
        return this.statistic.stream().mapToDouble( x -> x.estimatedProxySizeSquared() ).sum();
    }

    public double sumPlanAddedModifiedSizeSquared()
    { 
        return this.statistic.stream().mapToDouble( x -> x.planAddedModifiedSizeSquared()).sum();
    }

    public double sumActualAddedModifiedSizeSquared()
    { 
        return this.statistic.stream().mapToDouble( x -> x.actualAddedModifiedSizeSquared()).sum();
    }

    public double sumActualDevelopmentTimeSquared()
    { 
        return this.statistic.stream().mapToDouble( x -> x.actualDevelopmentTimeSquared()).sum();
    }
    
    public double sumEstimatedProxySizeActualAddedModifiedSize()
    { 
        return this.statistic.stream().mapToDouble( x -> x.estimatedProxySizeActualAddedModifiedSize()).sum();
    }

    public double sumEstimatedProxySizeActualDevelopmentTime()
    { 
        return this.statistic.stream().mapToDouble( x -> x.estimatedProxySizeActualDevelopmentTime()).sum();
    }

    public double sumPlanAddedModifiedSizeActualAddedModifiedSize()
    { 
        return this.statistic.stream().mapToDouble( x -> x.planAddedModifiedSizeActualAddedModifiedSize()).sum();
    }

    public double sumPlanAddedModifiedSizeActualDevelopmentTime()
    { 
        return this.statistic.stream().mapToDouble( x -> x. planAddedModifiedSizeActualDevelopmentTime()).sum();
    }

    public double avgEstimatedProxySize()
    { 
        return this.statistic.stream().mapToDouble( x -> x.getEstimatedProxySize()).sum() / this.statistic.size();
    }

    public double avgPlanAddedAndModifiedSize()
    { 
        return this.statistic.stream().mapToDouble( x -> x.getPlanAddedModifiedSize()).sum() / this.statistic.size(); 
    }

    public double avgActualAddedAndModifiedSize()
    { 
        return this.statistic.stream().mapToDouble( x -> x.getActualAddedModifiedSize()).sum() / this.statistic.size(); 
    }

    public double avgActualDevelopmentTime()
    { 
        return this.statistic.stream().mapToDouble( x -> x.getActualDevelopmentTime()).sum() / this.statistic.size(); 
    }

    public String calcPlanAddedModifiedSizeEPSAAM(int estimatedProxySize) 
    {        
        double calcTmp = this.sumEstimatedProxySizeActualAddedModifiedSize() - (this.statistic.size() * this.avgEstimatedProxySize() * this.avgActualAddedAndModifiedSize());
        double beta1 = calcTmp / (this.sumEstimatedProxySizeSquared() - (this.statistic.size() * this.avgEstimatedProxySize() * this.avgEstimatedProxySize())); 
        
        calcTmp = 0;
        calcTmp = ( this.statistic.size() * this.sumEstimatedProxySizeActualAddedModifiedSize()) - (sumEstimatedProxySize() * sumActualAddedModifiedSize());
        
        double calcTmpDiv = ((this.statistic.size() * this.sumEstimatedProxySizeSquared()) - ( sumEstimatedProxySize() * sumEstimatedProxySize())) * ((this.statistic.size() * this.sumActualAddedModifiedSizeSquared()) - (sumActualAddedModifiedSize() * sumActualAddedModifiedSize()));
       
        double relation = (calcTmp / Math.sqrt(calcTmpDiv));
        
        double beta0 = this.avgActualAddedAndModifiedSize() - (beta1 * this.avgEstimatedProxySize());

        return "<tr><td>" + padRight(beta0, 14) + "</td><td>" + padRight(beta1, 14) + "</td><td>" + padRight(relation, 14) + "</td><td>" + padRight(relation * relation, 14) + "</td><td>" + padRight((beta0 + (beta1 * estimatedProxySize)), 14) + "</td></tr>";
    }
    public String calcTimeEstmateEPSADT(int estimatedProxySize) 
    {
        double calcTmp = this.sumEstimatedProxySizeActualDevelopmentTime()- (this.statistic.size() * this.avgEstimatedProxySize() * this.avgActualDevelopmentTime());
        double beta1 = calcTmp / (this.sumEstimatedProxySizeSquared() - (this.statistic.size() * this.avgEstimatedProxySize() * this.avgEstimatedProxySize())); 
        
        double sumEstimatedProxySize = this.statistic.stream().mapToDouble( x -> x.getEstimatedProxySize()).sum(); 
        double sumActualDevelopmentTime = this.statistic.stream().mapToDouble( x -> x.getActualDevelopmentTime()).sum(); 
        
        calcTmp = 0;
        calcTmp = ( this.statistic.size() * this.sumEstimatedProxySizeActualDevelopmentTime()) - (sumEstimatedProxySize() * sumActualDevelopmentTime);
        
        double calcTmpDiv =  ((this.statistic.size() * this.sumEstimatedProxySizeSquared()) - ( sumEstimatedProxySize() * sumEstimatedProxySize())) * ((this.statistic.size() * this.sumActualDevelopmentTimeSquared()) - (sumActualDevelopmentTime * sumActualDevelopmentTime));
       
        double relation = (calcTmp / Math.sqrt(calcTmpDiv));
                
        double beta0 = this.avgActualDevelopmentTime()- (beta1 * this.avgEstimatedProxySize());

        return "<tr><td>" + padRight(beta0, 14) + "</td><td>" + padRight(beta1, 14) + "</td><td>" + padRight(relation, 14) + "</td><td>" + padRight(relation * relation, 14) + "</td><td>" + padRight((beta0 + (beta1 * estimatedProxySize)), 14) + "</td></tr>";
    }
    public String calcPlanAddedModifiedSizePAMSAAMS(int estimatedProxySize) 
    {
            
        double calcTmp = this.sumPlanAddedModifiedSizeActualAddedModifiedSize() - (this.statistic.size() * this.avgPlanAddedAndModifiedSize() * this.avgActualAddedAndModifiedSize());
        double beta1 = calcTmp / (this.sumPlanAddedModifiedSizeSquared() - (this.statistic.size() * this.avgPlanAddedAndModifiedSize() * this.avgPlanAddedAndModifiedSize())); 
        
        double sumPlanAddedModifiedSize = this.statistic.stream().mapToDouble(x -> x.getPlanAddedModifiedSize()).sum();
        
        calcTmp = 0;
        calcTmp = ( this.statistic.size() * this.sumPlanAddedModifiedSizeActualAddedModifiedSize()) - (sumPlanAddedModifiedSize * sumActualAddedModifiedSize());
        
        double calcTmpDiv = ((this.statistic.size() * this.sumPlanAddedModifiedSizeSquared()) - ( sumPlanAddedModifiedSize * sumPlanAddedModifiedSize)) * ((this.statistic.size() * this.sumActualAddedModifiedSizeSquared()) - (sumActualAddedModifiedSize() * sumActualAddedModifiedSize()));
       
        double relation = (calcTmp / Math.sqrt(calcTmpDiv));
        
        double beta0 = this.avgActualAddedAndModifiedSize() - (beta1 * this.avgPlanAddedAndModifiedSize());

        return "<tr><td>" + padRight(beta0, 14) + "</td><td>" + padRight(beta1, 14) + "</td><td>" + padRight(relation, 14) + "</td><td>" + padRight(relation * relation, 14) + "</td><td>" + padRight((beta0 + (beta1 * estimatedProxySize)), 14) + "</td></tr>";
    }
    public String calcTimeEstimatedPAMSADT(int estimatedProxySize) 
    { 
        double calcTmp = this.sumPlanAddedModifiedSizeActualDevelopmentTime()- (this.statistic.size() * this.avgPlanAddedAndModifiedSize()* this.avgActualDevelopmentTime());
        double beta1 = calcTmp / (this.sumPlanAddedModifiedSizeSquared()- (this.statistic.size() * this.avgPlanAddedAndModifiedSize() * this.avgPlanAddedAndModifiedSize())); 
        
        double sumPlanAddedModifiedSize = this.statistic.stream().mapToDouble(x -> x.getPlanAddedModifiedSize()).sum();
        double sumActualDevelopmentTime = this.statistic.stream().mapToDouble( x -> x.getActualDevelopmentTime()).sum();
        
        calcTmp = 0;
        calcTmp = ( this.statistic.size() * this.sumPlanAddedModifiedSizeActualDevelopmentTime()) - (sumPlanAddedModifiedSize * sumActualDevelopmentTime);
        
        double calcTmpDiv =  ((this.statistic.size() * this.sumPlanAddedModifiedSizeSquared()) - ( sumPlanAddedModifiedSize * sumPlanAddedModifiedSize)) * ((this.statistic.size() * this.sumActualDevelopmentTimeSquared()) - (sumActualDevelopmentTime * sumActualDevelopmentTime));
       
        double relation = (calcTmp / Math.sqrt(calcTmpDiv));

        double beta0 = this.avgActualDevelopmentTime()- (beta1 * this.avgPlanAddedAndModifiedSize());

        return "<tr><td>" + padRight(beta0, 14) + "</td><td>" + padRight(beta1, 14) + "</td><td>" + padRight(relation, 14) + "</td><td>" + padRight(relation * relation, 14) + "</td><td>" + padRight((beta0 + (beta1 * estimatedProxySize)), 14) + "</td></tr>" ;
    }
    
    public void printStatistics() 
    { 
        System.out.println("[Prog Num]   [EsAdModS]   [AAdMoSiz]   [ActDevTi]");
        for(Statistic item : this.statistic)
        {
            System.out.println(padRight(item.getEstimatedProxySize(), 14) + padRight(item.getPlanAddedModifiedSize(), 14) + padRight(item.getActualAddedModifiedSize(), 14) + padRight(item.getActualDevelopmentTime(), 14));
        }
        System.out.println("");
    } 

    private String padRight(double s, int n) 
    {
        DecimalFormat decimalFormat = new DecimalFormat("#.00");
        return String.format("%1$-" +  n + "s", decimalFormat.format(s));  
    }
}
