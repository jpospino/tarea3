import Model.LinealRegressionCalculator;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import spark.ModelAndView;
import spark.template.freemarker.FreeMarkerEngine;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static spark.Spark.*;

public class Main {

  public static void main(String[] args) {

    port(Integer.valueOf(System.getenv("PORT")));
    staticFileLocation("/public");

    
    get("/regresionLineal",  "application/json", (req, res) -> {
        
        LinealRegressionCalculator linealRegressionCalculator = new LinealRegressionCalculator();
        
        linealRegressionCalculator = new LinealRegressionCalculator();
        linealRegressionCalculator.addStatictics(1, 130.0, 163.0, 186.0, 15.0);
        linealRegressionCalculator.addStatictics(2, 650.0, 765.0, 699.0, 69.9);
        linealRegressionCalculator.addStatictics(3, 99.0, 141.0, 132.0, 6.50);
        linealRegressionCalculator.addStatictics(4, 150.0, 166.0, 272.0, 22.40);
        linealRegressionCalculator.addStatictics(5, 128.0, 137.0, 291.0, 28.4);
        linealRegressionCalculator.addStatictics(6, 302.0, 355.0, 331.0, 65.9);
        linealRegressionCalculator.addStatictics(7, 95.0, 136.0, 199.0, 19.4);
        linealRegressionCalculator.addStatictics(8, 945.0, 1206.0, 1890.0, 198.7);
        linealRegressionCalculator.addStatictics(9, 368.0, 433.0, 788.0, 38.8);
        linealRegressionCalculator.addStatictics(10, 961.0, 1130.0, 1601.0, 138.2);
        
        String salida =  "<a>Proxy = " + req.queryParams("proxy").toString() + "</a><br><table  BORDER=10 BORDERCOLOR=RED><tr><td>[B0]</td><td>[B1]</td><td>[r_xy]</td><td>[r^2]</td><td>[y_k]</td></tr>";
        int proxySize = Integer.parseInt(req.queryParams("proxy").toString());
        
        salida += linealRegressionCalculator.calcPlanAddedModifiedSizeEPSAAM(proxySize);
        salida += linealRegressionCalculator.calcTimeEstmateEPSADT(proxySize);
        salida += linealRegressionCalculator.calcPlanAddedModifiedSizePAMSAAMS(proxySize);
        salida += linealRegressionCalculator.calcTimeEstimatedPAMSADT(proxySize) + "</table>";
        
        return salida;
    });
  }
}
